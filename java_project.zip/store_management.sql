CREATE DATABASE store_management;
USE store_management;

CREATE TABLE products (
  product_id INT AUTO_INCREMENT PRIMARY KEY,
  product_name VARCHAR(100),
  quantity INT,
  price DECIMAL(10,2)
);

INSERT INTO products (product_name, quantity, price) VALUES
('Laptop', 5, 55000.00),
('Mouse', 20, 500.00),
('Keyboard', 15, 1500.00);

