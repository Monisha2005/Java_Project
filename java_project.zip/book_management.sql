-- Create Database
CREATE DATABASE bookstore_management;
USE bookstore_management;

-- Books Table
CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(150),
    quantity INT NOT NULL DEFAULT 0,
    price DECIMAL(10,2) NOT NULL
);

-- Customers Table
CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(100),
    city VARCHAR(100)
);

-- Sales Table
CREATE TABLE sales (
    sale_id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT,
    customer_id INT,
    quantity_sold INT NOT NULL,
    sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
);

-- Insert sample books
INSERT INTO books (title, author, quantity, price) VALUES
('The Silent Patient', 'Alex Michaelides', 12, 499.00),
('Atomic Habits', 'James Clear', 20, 599.00),
('Wings of Fire', 'A.P.J. Abdul Kalam', 10, 399.00),
('The Alchemist', 'Paulo Coelho', 15, 350.00),
('Ikigai', 'Héctor García', 18, 450.00);

-- Insert sample customers
INSERT INTO customers (name, email, city) VALUES
('Priya Sharma', 'priya.s@example.com', 'Bangalore'),
('Rahul Mehta', 'rahul.m@example.com', 'Mumbai'),
('Kavya Nair', 'kavya.n@example.com', 'Kochi');

SHOW TABLES;

DESCRIBE books;
DESCRIBE customers;
DESCRIBE sales;


SELECT*FROM books;
SELECT*FROM customers;
SELECT*FROM sales;




