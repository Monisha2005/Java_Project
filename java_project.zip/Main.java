import java.sql.*;

public class Main {
    public static void Main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/yourDatabase";
        String user = "root";
        String password = "yourPassword";

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to Database
            Connection con = DriverManager.getConnection(url, user, password);

            System.out.println("Connected to Database!");

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM yourTable");

            while (rs.next()) {
                System.out.println(rs.getInt(1) + "  " + rs.getString(2));
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}